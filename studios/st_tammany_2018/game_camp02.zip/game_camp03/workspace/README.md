  _____                         _____          _         _____                      
 / ____|                       / ____|        | |       / ____|                     
| |  __  __ _ _ __ ___   ___  | |     ___   __| | ___  | |     __ _ _ __ ___  _ __  
| | |_ |/ _` | '_ ` _ \ / _ \ | |    / _ \ / _` |/ _ \ | |    / _` | '_ ` _ \| '_ \ 
| |__| | (_| | | | | | |  __/ | |___| (_) | (_| |  __/ | |___| (_| | | | | | | |_) |
 \_____|\__,_|_| |_| |_|\___|  \_____\___/ \__,_|\___|  \_____\__,_|_| |_| |_| .__/ 
                                                                             | |    
                                                                             |_|                                                         


Hi there! This is the Game Code Camp Workspace!

Game Art:
    To import your game art from Piskel.
    1. Download your spritesheets or png images from Piskel App (export option) to local computer
    2. Select File in Cloud9 navbar, then select 'Upload Local Files...'
    3. Drag your image into the upload menu, and it should appear in Cloud9

Game Design:
   To load the Tiled map editor.
   1. launch c9vnc from CLI using the command c9vnc
   2. click the link that displays in the terminal and open
   3. connect to the novnc
   4. right click to open fluxbox
   5. select 'Game Dev' then Tiled

Game Code:
    To run a Phaser project
    1. navigate to the game directory
    2. open the index.html into the editor
    3. press the 'run' button
    4. open the link that displays
