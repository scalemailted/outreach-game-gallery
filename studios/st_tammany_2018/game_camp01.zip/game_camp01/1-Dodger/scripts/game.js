var config = new Object();

config.width = 640;
config.height = 480;
config.scene = [ PlayScene ];
config.physics = { default: 'arcade'};

var game = new Phaser.Game(config);