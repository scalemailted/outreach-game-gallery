class Level2 extends Level1
{
     constructor()
     {
         super('Level2')
         this.map_key = 'map2';
         this.map_json = 'level2.json';
     }
}