viewport = new Object();

viewport.width  = renderer.canvas.width;
viewport.height = renderer.canvas.height;
