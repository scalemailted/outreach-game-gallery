var maps = [

             [
                "############                     ",
                "DVV A VV   D                     ",
                "D   #      D                     ",
                "D   V  A   D                     ",
                "D     ###  D                     ",
                "D#      D  D                     ",
                "DAA   # D@ D                     ",
                "D##   V  # D                     ",
                "DVV    ##  D                     ",
                "D    #  AAAD                     ",
                "DAA  V  ###D                     ",
                "D###       D                     ",
                "D!         D                     ",
                "D##########D                     "
             ],

            [
                "############                     ",
                "D          D                     ",
                "D@         D                     ",
                "D          D                     ",
                "D          D                     ",
                "D          D                     ",
                "D          D                     ",
                "D          D                     ",
                "D          D                     ",
                "D          D                     ",
                "D          D                     ",
                "D          D                     ",
                "DAAAAAAAAA!D                     ",
                "############                     "
             ],
             
             [
                "# @        D                  ",
                "D #        D                  ",
                "D          D                  ",
                "D          D################   ",
                "D          v                 !",
                "D                           D",
                "D           A              D",
                "D          ################,",
                "D          D                   ",
                "D          D               ",
                "DAAAAAAAAA D                   ",
                "D##########D"
             ]];