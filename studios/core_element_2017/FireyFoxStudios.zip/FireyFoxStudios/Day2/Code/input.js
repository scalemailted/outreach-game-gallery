input = new Object();

input.x = null;
input.y = null;

input.start = function()
{

}


