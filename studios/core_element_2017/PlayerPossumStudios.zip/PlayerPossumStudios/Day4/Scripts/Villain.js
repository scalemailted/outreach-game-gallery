var villain = new Object();

villain.image = new Image()
villain.image.src = "Assets/Villain/PlayerPossumAManWithNoHead.png";

villain.width = 32;
villain.height = 32;