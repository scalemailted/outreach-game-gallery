var maps = [[
                "############",
                "JVV ! V    J",
                "J   #      J",
                "J      AA  J",
                "J     ###  J",
                "J#     JJ  J",
                "JAA   # #  J",
                "J##   V  # J",
                "JVV    ##  J",
                "J    #  AAAJ",
                "JAA  V  ###J",
                "J###       J",
                "J@         J",
                "J##########J"
             ],

             [
                "############",
                "JVV A VV   J",
                "J   #      J",
                "J   V  A   J",
                "J     ###  J",
                "J#      #  J",
                "JAA   # #@ J",
                "J##   V  # J",
                "JVV    ##  J",
                "J    #  AAAJ",
                "JAA  V  ###J",
                "J###       J",
                "J!         J",
                "J##########J"
             ],

            [
                "############",
                "J          J",
                "J@         J",
                "J          J",
                "J          J",
                "J          J",
                "J          J",
                "J          J",
                "J          J",
                "J          J",
                "J          J",
                "J          J",
                "JAAAAAAAAA!J",
                "J##########J"
                 
                 ],
                 
                 
            [
                "############",
                "J@          ",
                "JBBBBBBBBBBJ",
                "J           ",
                "J  A  ABBBBJ",
                "J          J",
                "J          J",
                "JAAAA      J",
                "J  AAAAA#A J",
                "J          J",
                "J          J",
                "J BBBBBBBBBJ",
                "J         !J",
                "JBBBBBBBBBBJ"
                ], 
                
            [
                "############",
                "J          J",
                "J@   A     J",
                "J######    J",
                "J          J",
                "J       AAAJ",
                "J          J",
                "J          J",
                "J  ###     J",
                "J  !       J",
                "J  B   ### J",
                "JLLLLLLLLLLJ",
                "J??????????J",
                "J##########J"
                    
                ]];