var config =
{
    width:640,
    height:480,
    scene: [ PlayScene ],
    physics: { default:'arcade' }
};

var game = new Phaser.Game(config);